HDC = HDC or {}

local Safe        = HDC.Safe
local ClientState = HDC.ClientState

local KEY = "MuteChatGlobal"

local function enabled()
    return ClientState.Get(KEY)
end

Safe.PatchMethod("Barotrauma.ChatBox", "AddToGUIUpdateList", nil, function(instance, ptable)
    if not enabled() then return end
    ptable.PreventExecution = true
end, Hook.HookMethodType.Before)

Safe.PatchMethod("Barotrauma.ChatBox", "SelectInputBox", nil, function(instance, ptable)
    if not enabled() then return end
    ptable.PreventExecution = true
end, Hook.HookMethodType.Before)

Safe.AddHook("think", "HDC.ChatMuteGlobal.DisableInput", function()
    if not enabled() then return end
    local chatBox = Safe.Get(function() return GameMain.GameSession.CrewManager.ChatBox end)
    if chatBox == nil then return end
    Safe.Set(function() chatBox.GUIFrame.Visible    = false end)
    Safe.Set(function() chatBox.InputBox.Enabled    = false end)
    Safe.Set(function() chatBox.InputBox.Text       = "" end)
end)
